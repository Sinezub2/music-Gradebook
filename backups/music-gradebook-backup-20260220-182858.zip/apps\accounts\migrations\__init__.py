# apps/accounts/migrations/__init__.py
# This file is intentionally left blank to mark this directory as a Python package.