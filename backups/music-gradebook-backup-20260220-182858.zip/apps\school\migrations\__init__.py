# apps/school/migrations/__init__.py
