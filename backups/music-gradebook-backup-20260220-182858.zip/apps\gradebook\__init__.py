# apps/school/__init__.py
